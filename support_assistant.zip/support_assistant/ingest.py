"""
Ingestion + embedding stage of the RAG pipeline.

Loads the 8 Zepto policy documents from docs/, chunks them (one chunk per
document -- reasonable given their short, single-topic length), embeds each
chunk locally with sentence-transformers' all-MiniLM-L6-v2 (no API key, no
network call needed at inference time beyond the one-time model download),
and stores the embeddings + text in a persistent ChromaDB collection.

This module is imported by main.py at FastAPI startup, and can also be run
standalone (`python ingest.py`) to (re)build the index.
"""
import os
import glob

import chromadb
from sentence_transformers import SentenceTransformer

DOCS_DIR = os.path.join(os.path.dirname(__file__), "docs")
CHROMA_DIR = os.path.join(os.path.dirname(__file__), "chroma_db")
COLLECTION_NAME = "zepto_policies"
EMBEDDING_MODEL_NAME = "all-MiniLM-L6-v2"

_embedding_model = None


def get_embedding_model() -> SentenceTransformer:
    global _embedding_model
    if _embedding_model is None:
        _embedding_model = SentenceTransformer(EMBEDDING_MODEL_NAME)
    return _embedding_model


def load_documents() -> dict:
    """Load each docs/doc_XX.txt file. One file == one chunk (Task 1)."""
    chunks = {}
    for path in sorted(glob.glob(os.path.join(DOCS_DIR, "doc_*.txt"))):
        doc_id = os.path.splitext(os.path.basename(path))[0]  # e.g. "doc_01"
        with open(path, "r", encoding="utf-8") as f:
            chunks[doc_id] = f.read().strip()
    return chunks


def build_index(persist: bool = True) -> "chromadb.Collection":
    """Embed every chunk and (re)build the ChromaDB collection."""
    client = (
        chromadb.PersistentClient(path=CHROMA_DIR)
        if persist
        else chromadb.EphemeralClient()
    )

    # Start clean so re-running ingestion doesn't duplicate/stale-out entries.
    try:
        client.delete_collection(COLLECTION_NAME)
    except Exception:
        pass
    collection = client.create_collection(
        name=COLLECTION_NAME, metadata={"hnsw:space": "cosine"}
    )

    chunks = load_documents()
    model = get_embedding_model()

    ids = list(chunks.keys())
    texts = [chunks[doc_id] for doc_id in ids]
    embeddings = model.encode(texts, convert_to_numpy=True).tolist()

    collection.add(
        ids=ids,
        embeddings=embeddings,
        documents=texts,
        metadatas=[{"source": f"{doc_id}.txt"} for doc_id in ids],
    )
    return collection


def get_or_build_collection() -> "chromadb.Collection":
    """Used by the app at startup: reuse a persisted index if present, else build it."""
    client = chromadb.PersistentClient(path=CHROMA_DIR)
    try:
        collection = client.get_collection(COLLECTION_NAME)
        if collection.count() == len(load_documents()):
            return collection
    except Exception:
        pass
    return build_index(persist=True)


if __name__ == "__main__":
    col = build_index()
    print(f"Indexed {col.count()} chunks into ChromaDB collection '{COLLECTION_NAME}'.")
