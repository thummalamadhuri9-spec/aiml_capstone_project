# Zepto Support Assistant (`/support_assistant`)

A small LangGraph-orchestrated RAG service over Zepto's own policy corpus, wrapped
in FastAPI, graded entirely through a deterministic offline mock mode.

> **A note on how this was built:** the code below was written and hand-traced
> for correctness, but the sandbox used to produce it has no network access, so
> `pip install -r requirements.txt` could not actually be run here to capture
> live transcripts. Everything under "Example calls" is a manual trace through
> the deterministic mock-mode code paths (which don't depend on model weights
> for the *logic*, only for *which* chunk is retrieved). **Before submitting,
> run the two commands under "Reproduce the example calls yourself" and
> replace the transcripts below with your own real output** — it should match
> almost exactly, since the mock paths are fully deterministic once retrieval
> returns a top chunk, and these two example queries are unambiguous matches
> for their documents.

## Setup

```bash
cd support_assistant
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt

# Build the ChromaDB index (also happens automatically on first API startup)
python ingest.py

# Run the API (MOCK_LLM defaults to 1 -- fully offline, graded baseline)
uvicorn main:app --host 0.0.0.0 --port 7860
```

## Reproduce the example calls yourself

```bash
curl -s -X POST http://localhost:7860/ask \
  -H "Content-Type: application/json" \
  -d '{"query": "What is the delivery fee for an order under INR 149?"}' | python -m json.tool

curl -s -X POST http://localhost:7860/ask \
  -H "Content-Type: application/json" \
  -d '{"query": "What is the capital of France?"}' | python -m json.tool
```

## Example calls (MOCK_LLM left at its default)

### 1. Policy question -> routed to `retrieve_and_answer`

Request:
```json
POST /ask
{"query": "What is the delivery fee for an order under INR 149?"}
```

Response:
```json
{
  "answer": "Based on the retrieved context: Zepto delivers grocery and household essentials to serviceable pin codes within 10 to 30 minutes of order confirmation, depending on the customer's del",
  "sources": ["doc_01", "doc_05", "doc_03"],
  "confidence": 1.0
}
```
`classify_intent` matched the keyword `"delivery"` in the query and routed to
`policy_question`. Retrieval returned `doc_01` (Delivery Policy) as the top
match, and `retrieve_and_answer`'s mock branch built the canned
`"Based on the retrieved context: {snippet}"` string from its first ~200
characters, with no LLM call made. (`sources` beyond the top hit will vary
slightly by exact embedding-model output; `doc_01` as the #1 result is
deterministic given the query's vocabulary overlap with that document.)

### 2. Unrelated question -> routed to `direct_answer`

Request:
```json
POST /ask
{"query": "What is the capital of France?"}
```

Response:
```json
{
  "answer": "I can only answer questions about Zepto policies right now.",
  "sources": [],
  "confidence": 1.0
}
```
`classify_intent` found none of the policy keywords in the query, so it
routed to `general_question` -> `direct_answer`, which returned the fixed
canned string with `sources = []`, again with no LLM call made.

## Architecture: ingestion -> embedding -> retrieval -> generation

**Ingestion** (`ingest.py::load_documents`): the 8 policy documents live as
plain-text files in `docs/doc_01.txt` … `docs/doc_08.txt`, one Zepto policy
per file (Delivery, Returns & Refunds, Membership Tiers, Order Tracking,
Cancellation, Damaged/Missing Items, Gift Cards, Support Hours). Given how
short and single-topic each file is, chunking is one chunk per document —
`load_documents` simply reads each file into a dict keyed by `doc_01` …
`doc_08`.

**Embedding** (`ingest.py::build_index` / `get_or_build_collection`): each
chunk's text is embedded locally with `sentence-transformers`'
`all-MiniLM-L6-v2` model (`get_embedding_model`) — no API key or network call
needed beyond the one-time model download. The 8 resulting vectors, their raw
text, and a `source` metadata field are written into a persistent ChromaDB
collection named `zepto_policies` (cosine-similarity space), stored under
`support_assistant/chroma_db/`. `get_or_build_collection` reuses this
persisted collection on subsequent runs, rebuilding it only if it's missing
or out of sync with `docs/`.

**Routing** (`main.py::classify_intent` + `route_after_classify`): the
LangGraph `StateGraph`'s entry node. In the graded mock mode it uses a
keyword heuristic over the lowercased query (`"delivery"`, `"return"`,
`"refund"`, `"membership"`, `"tracking"`, `"cancel"`, `"gift card"`,
`"support hours"`) to set `state["intent"]` to `policy_question` or
`general_question`, with no LLM call. A conditional edge
(`add_conditional_edges`) then routes to one of two nodes based on that
intent.

**Retrieval** (`main.py::retrieve_and_answer`): for `policy_question`
queries, the query is embedded with the same `all-MiniLM-L6-v2` model and
`collection.query(...)` retrieves the top-3 most similar chunks from
ChromaDB by cosine similarity. This step always runs for real, in both
`MOCK_LLM` modes, since it needs no API key.

**Generation**: only the final answer-composition step inside
`retrieve_and_answer` (and, symmetrically, inside `main.py::direct_answer`
for `general_question` queries) branches on `MOCK_LLM`:
- **`MOCK_LLM` unset or `"1"` (default, graded baseline):** no LLM call.
  `retrieve_and_answer` returns
  `f"Based on the retrieved context: {top_chunk_snippet}"` (first ~200 chars
  of the top retrieved chunk); `direct_answer` returns the fixed string
  `"I can only answer questions about Zepto policies right now."` Both
  populate the `AskResponse` schema (`answer`/`sources`/`confidence`)
  deterministically from code — `sources` is the list of retrieved chunk IDs
  (empty for `direct_answer`), `confidence` is fixed at `1.0`.
- **`MOCK_LLM=0` (optional, ungraded extension):** `retrieve_and_answer`
  builds a role–context–task–format–length prompt via `prompts.build_prompt`
  (grounded only in the 3 retrieved chunks, with a negative constraint
  against using outside knowledge and an embedded few-shot example) and
  sends it to a real LLM through `llm_client.call_llm` (Groq's free-tier,
  OpenAI-compatible endpoint by default). `direct_answer` does the same via
  `prompts.build_direct_prompt`, with no retrieval step. In both cases the
  raw LLM output is parsed and validated against the `AskResponse` Pydantic
  model in `main.py::_generate_with_schema_retries`; on a validation
  failure it retries up to `MAX_SCHEMA_RETRIES = 2` additional times with a
  corrective instruction appended to the prompt, and returns a clearly
  `[ERROR]`-prefixed response with `confidence = 0.0` if it still can't
  validate.

**Structured output** (`schemas.py::AskResponse`): every `/ask` response,
regardless of mode, is validated against this Pydantic model
(`answer: str`, `sources: list[str]`, `confidence: float` in `[0, 1]`)
before FastAPI serializes it — `main.py::ask` builds `AskResponse` directly
from the final `GraphState` returned by `compiled_graph.invoke(...)`.

```
docs/*.txt --(load_documents)--> chunks --(all-MiniLM-L6-v2)--> embeddings
                                                                    |
                                                                    v
                                                    ChromaDB "zepto_policies"
                                                                    |
query --(classify_intent, keyword heuristic)--> intent              |
   |                                                                 |
   |-- policy_question --> retrieve_and_answer --(query embedding)--+
   |                              |
   |                       [MOCK_LLM=1] canned "Based on the retrieved context: ..."
   |                       [MOCK_LLM=0] structured prompt -> real LLM -> schema retry
   |
   '-- general_question --> direct_answer
                                  |
                           [MOCK_LLM=1] fixed canned string
                           [MOCK_LLM=0] structured prompt -> real LLM -> schema retry
                                  |
                                  v
                      AskResponse (answer / sources / confidence)
```

## Running with Docker (required, graded baseline)

```bash
cd support_assistant
docker build -t zepto-support-assistant .
docker run -p 7860:7860 zepto-support-assistant
# then POST to http://localhost:7860/ask as above -- MOCK_LLM=1 by default in the image
```

## Optional extensions (not required for grading)

- **Real LLM (`MOCK_LLM=0`):** sign up for a free Groq account at
  console.groq.com (no credit card required), export `GROQ_API_KEY`, and run
  with `MOCK_LLM=0 uvicorn main:app --host 0.0.0.0 --port 7860` (or
  `docker run -e MOCK_LLM=0 -e GROQ_API_KEY=... -p 7860:7860 zepto-support-assistant`).
  Any other LLM API with a genuinely free (non-trial) tier can be substituted
  by editing `llm_client.py`.
- **Hugging Face Spaces deployment:** not attempted in this submission — the
  Dockerfile above is buildable/runnable locally as-is, which is the required
  baseline.
