"""Pydantic models for the /ask API contract."""
from typing import List
from pydantic import BaseModel, Field


class AskRequest(BaseModel):
    query: str = Field(..., description="The user's natural-language question.")


class AskResponse(BaseModel):
    answer: str = Field(..., description="The generated / templated answer.")
    sources: List[str] = Field(
        default_factory=list,
        description="Chunk/document IDs used to ground the answer. Empty for general_question answers.",
    )
    confidence: float = Field(..., ge=0.0, le=1.0, description="Confidence score between 0 and 1.")
