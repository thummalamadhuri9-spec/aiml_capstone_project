"""
Optional MOCK_LLM=0 extension only. Not imported/used on the graded
default (mock) path.

A tiny wrapper around Groq's free-tier, OpenAI-compatible chat completions
endpoint. Any other LLM API with a genuinely free tier can be substituted by
changing GROQ_API_URL / GROQ_MODEL / the auth header below.

Requires GROQ_API_KEY to be set in the environment (e.g. via a .env file or
a Docker/HF Space secret) -- never hardcode it.
"""
import os
import json
import requests

GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions"
GROQ_MODEL = os.getenv("GROQ_MODEL", "llama-3.1-8b-instant")


def call_llm(prompt: str, temperature: float = 0.0) -> str:
    """Send `prompt` to the real LLM and return its raw text response."""
    api_key = os.getenv("GROQ_API_KEY")
    if not api_key:
        raise RuntimeError(
            "MOCK_LLM=0 was set but GROQ_API_KEY is not configured. "
            "Set it as an environment variable / secret, or leave MOCK_LLM unset "
            "to use the fully offline graded baseline."
        )
    resp = requests.post(
        GROQ_API_URL,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        data=json.dumps(
            {
                "model": GROQ_MODEL,
                "temperature": temperature,
                "messages": [{"role": "user", "content": prompt}],
            }
        ),
        timeout=30,
    )
    resp.raise_for_status()
    data = resp.json()
    return data["choices"][0]["message"]["content"]
